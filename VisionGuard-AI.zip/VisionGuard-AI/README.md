# VisionGuard AI
### AI-Powered Object Detection & Video Analytics

**Author:** Şamil Sayedali  
**Domain:** Artificial Intelligence · Computer Vision · Deep Learning

VisionGuard AI is an interactive computer-vision application that detects objects in uploaded images and videos using a pretrained YOLO model. It annotates media with bounding boxes, summarizes detected classes, and exports detection data to CSV.

## Features
- Image object detection
- Frame-by-frame video analysis
- Bounding boxes, class labels, and confidence scores
- Object-count summaries
- Frame-level detection export
- Interactive Streamlit interface
- Adjustable confidence threshold and model selection

## Tech stack
Python · Ultralytics YOLO · OpenCV · Streamlit · Pandas · NumPy

## Project structure
```text
VisionGuard-AI/
├── app.py
├── requirements.txt
├── README.md
├── LICENSE
├── .gitignore
├── src/
│   ├── __init__.py
│   └── detector.py
└── tests/
    └── test_detector_helpers.py
```

## Run locally

Python 3.10 or newer is recommended.

1. Clone the repository:
   ```bash
   git clone https://github.com/YOUR-USERNAME/VisionGuard-AI.git
   cd VisionGuard-AI
   ```

2. Create and activate a virtual environment:
   ```bash
   python -m venv .venv
   # Windows:
   .venv\Scripts\activate
   # macOS/Linux:
   source .venv/bin/activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Start the app:
   ```bash
   streamlit run app.py
   ```

The selected YOLO weights are downloaded by Ultralytics on first use. An internet connection is required for the initial model download.

## How it works
1. Open the Streamlit application.
2. Select a YOLO model and confidence threshold in the sidebar.
3. Upload an image or video.
4. Run analysis and inspect the annotated output.
5. Download image detections, video summaries, or frame-level results as CSV.

## Evaluation notes
This repository uses pretrained YOLO weights; it does not claim that the author trained the underlying model from scratch. Detection quality varies with lighting, resolution, occlusion, camera angle, and the model's supported classes. For a meaningful evaluation, test on a representative dataset and report precision, recall, mAP, inference speed, and hardware configuration.

## Future improvements
- Object tracking with persistent IDs
- Configurable region-of-interest alerts
- Custom dataset training and validation
- Model benchmarking and performance dashboard
- REST API deployment

## Model and data attribution
The application uses Ultralytics YOLO pretrained weights (downloaded separately on first run). Review the model and package licenses and terms before commercial use. No sample media or model weights are redistributed in this repository.

## Responsible use
Use media that you own or have permission to process. Do not use this demonstration as the sole basis for safety-critical decisions, identification, or monitoring of people.

## License
This project code is released under the MIT License. Third-party libraries and pretrained weights remain subject to their own licenses and terms.

from collections import Counter
from pathlib import Path
import cv2
import numpy as np
import pandas as pd
from ultralytics import YOLO


def load_model(model_name: str = "yolo11n.pt"):
    """Load a pretrained Ultralytics YOLO model."""
    return YOLO(model_name)


def _result_to_rows(result, frame_number=None):
    rows = []
    boxes = result.boxes
    if boxes is None:
        return rows

    names = result.names
    for box in boxes:
        class_id = int(box.cls.item())
        confidence = float(box.conf.item())
        x1, y1, x2, y2 = [int(v) for v in box.xyxy[0].tolist()]
        row = {
            "class_id": class_id,
            "class_name": names.get(class_id, str(class_id)),
            "confidence": round(confidence, 4),
            "x1": x1, "y1": y1, "x2": x2, "y2": y2,
        }
        if frame_number is not None:
            row["frame"] = frame_number
        rows.append(row)
    return rows


def analyze_image(model, image_bytes: bytes, confidence: float = 0.35):
    """Return an annotated BGR image and a DataFrame of detections."""
    encoded = np.frombuffer(image_bytes, dtype=np.uint8)
    image = cv2.imdecode(encoded, cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError("The uploaded file could not be decoded as an image.")

    results = model.predict(source=image, conf=confidence, verbose=False)
    annotated = results[0].plot()
    rows = _result_to_rows(results[0])
    return annotated, pd.DataFrame(rows, columns=[
        "class_id", "class_name", "confidence", "x1", "y1", "x2", "y2"
    ])


def analyze_video(model, input_path: str, output_path: str, confidence: float = 0.35):
    """Process a video and return class summary plus frame-level detections."""
    capture = cv2.VideoCapture(input_path)
    if not capture.isOpened():
        raise ValueError("Could not open the uploaded video.")

    fps = capture.get(cv2.CAP_PROP_FPS)
    if not fps or fps <= 0:
        fps = 25.0
    width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
    if width <= 0 or height <= 0:
        capture.release()
        raise ValueError("The video has invalid frame dimensions.")

    writer = cv2.VideoWriter(
        output_path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (width, height)
    )
    if not writer.isOpened():
        capture.release()
        raise RuntimeError("Could not create the annotated output video.")

    all_rows = []
    frame_number = 0
    try:
        while True:
            ok, frame = capture.read()
            if not ok:
                break
            results = model.predict(source=frame, conf=confidence, verbose=False)
            result = results[0]
            writer.write(result.plot())
            all_rows.extend(_result_to_rows(result, frame_number))
            frame_number += 1
    finally:
        capture.release()
        writer.release()

    columns = ["class_id", "class_name", "confidence", "x1", "y1", "x2", "y2", "frame"]
    frame_df = pd.DataFrame(all_rows, columns=columns)
    if frame_df.empty:
        summary = pd.DataFrame(columns=["class_name", "count"])
    else:
        summary = (
            frame_df.groupby("class_name")
            .size()
            .sort_values(ascending=False)
            .rename("count")
            .reset_index()
        )
    return summary, frame_df

from types import SimpleNamespace
from src.detector import _result_to_rows


class FakeTensor:
    def __init__(self, value):
        self.value = value

    def item(self):
        return self.value

    def tolist(self):
        return self.value


def test_result_to_rows_extracts_detection_fields():
    box = SimpleNamespace(
        cls=FakeTensor(2),
        conf=FakeTensor(0.91),
        xyxy=[FakeTensor([10, 20, 100, 120])],
    )
    result = SimpleNamespace(boxes=[box], names={2: "car"})
    rows = _result_to_rows(result, frame_number=7)
    assert len(rows) == 1
    assert rows[0]["class_name"] == "car"
    assert rows[0]["confidence"] == 0.91
    assert rows[0]["frame"] == 7

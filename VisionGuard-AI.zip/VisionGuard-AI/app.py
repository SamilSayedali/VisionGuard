from pathlib import Path
import tempfile
import pandas as pd
import streamlit as st
from src.detector import load_model, analyze_image, analyze_video

st.set_page_config(page_title="VisionGuard AI", page_icon="👁️", layout="wide")
st.title("👁️ VisionGuard AI")
st.caption("AI-powered object detection and video analytics")
st.markdown(
    "Analyze images and videos with a pretrained YOLO model. "
    "Review detected objects, confidence scores, and downloadable analytics."
)

with st.sidebar:
    st.header("Detection settings")
    model_name = st.selectbox("YOLO model", ["yolo11n.pt", "yolov8n.pt"], index=0)
    confidence = st.slider("Confidence threshold", 0.10, 0.95, 0.35, 0.05)
    st.info("The selected pretrained weights are downloaded automatically on first use.")

@st.cache_resource(show_spinner="Loading AI model...")
def get_model(name):
    return load_model(name)

try:
    model = get_model(model_name)
except Exception as exc:
    st.error(f"Could not load the model: {exc}")
    st.stop()

image_tab, video_tab, about_tab = st.tabs(["🖼️ Image analysis", "🎞️ Video analysis", "ℹ️ About"])

with image_tab:
    uploaded_image = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png", "webp"], key="image")
    if uploaded_image:
        col1, col2 = st.columns(2)
        with col1:
            st.image(uploaded_image, caption="Original image", use_container_width=True)
        if st.button("Analyze image", type="primary"):
            with st.spinner("Detecting objects..."):
                result_image, detections = analyze_image(model, uploaded_image.getvalue(), confidence)
            with col2:
                st.image(result_image, caption="Detection result", channels="BGR", use_container_width=True)
            if detections.empty:
                st.warning("No objects detected at this confidence threshold.")
            else:
                st.subheader("Detection summary")
                counts = detections.groupby("class_name").size().sort_values(ascending=False)
                metric_cols = st.columns(min(4, len(counts)))
                for idx, (label, count) in enumerate(counts.items()):
                    metric_cols[idx % len(metric_cols)].metric(label, int(count))
                st.dataframe(detections, use_container_width=True, hide_index=True)
                st.download_button(
                    "Download detections (CSV)",
                    detections.to_csv(index=False).encode("utf-8"),
                    "visionguard_image_detections.csv",
                    "text/csv",
                )

with video_tab:
    uploaded_video = st.file_uploader("Upload a video", type=["mp4", "avi", "mov", "mkv"], key="video")
    if uploaded_video:
        st.video(uploaded_video)
        if st.button("Analyze video", type="primary"):
            suffix = Path(uploaded_video.name).suffix or ".mp4"
            with tempfile.TemporaryDirectory() as temp_dir:
                input_path = Path(temp_dir) / f"input{suffix}"
                output_path = Path(temp_dir) / "annotated.mp4"
                input_path.write_bytes(uploaded_video.getvalue())
                try:
                    with st.spinner("Analyzing video frame by frame..."):
                        summary, frame_rows = analyze_video(
                            model, str(input_path), str(output_path), confidence
                        )
                    if output_path.exists() and output_path.stat().st_size:
                        st.subheader("Annotated video")
                        st.video(output_path.read_bytes())
                    if not summary.empty:
                        st.subheader("Detected object counts")
                        st.bar_chart(summary.set_index("class_name")["count"])
                        st.dataframe(summary, use_container_width=True, hide_index=True)
                        st.download_button(
                            "Download video summary (CSV)",
                            summary.to_csv(index=False).encode("utf-8"),
                            "visionguard_video_summary.csv",
                            "text/csv",
                        )
                    else:
                        st.info("No objects were detected.")
                    if not frame_rows.empty:
                        st.download_button(
                            "Download frame-level detections (CSV)",
                            frame_rows.to_csv(index=False).encode("utf-8"),
                            "visionguard_frame_detections.csv",
                            "text/csv",
                        )
                except Exception as exc:
                    st.error(f"Video analysis failed: {exc}")

with about_tab:
    st.subheader("Project overview")
    st.write(
        "VisionGuard AI is a computer-vision portfolio project that applies a "
        "pretrained YOLO detector to uploaded media and turns detections into "
        "simple, exportable analytics."
    )
    st.markdown("""
    **Pipeline**
    1. Upload an image or video.
    2. Run object detection with YOLO.
    3. Annotate media with bounding boxes and labels.
    4. Aggregate detections into class counts.
    5. Export the results as CSV.

    **Important:** This project uses pretrained third-party model weights. The
    model's accuracy depends on image quality, camera angle, lighting, and the
    classes represented in its training data. It is a demonstration/portfolio
    tool, not a certified safety or surveillance system.
    """)
    st.caption("Created by: Şamil Sayedali")
